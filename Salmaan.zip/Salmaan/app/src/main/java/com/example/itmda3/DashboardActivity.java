package com.example.itmda3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class DashboardActivity extends AppCompatActivity {

    Button btnHeartCalculator, btnReports, btnRecommendations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        btnHeartCalculator = findViewById(R.id.btnHeartCalculator);
        btnReports = findViewById(R.id.btnReports);
        btnRecommendations = findViewById(R.id.btnRecommendations);

        // Open Heart Risk Calculator
        btnHeartCalculator.setOnClickListener(v -> {
            startActivity(new Intent(this, com.example.itmda3.HeartCalculatorActivity.class));
        });

        // Open Reports Screen
        btnReports.setOnClickListener(v -> {
            startActivity(new Intent(this, com.example.itmda3.ReportsActivity.class));
        });

        // Open Recommendations Screen
        btnRecommendations.setOnClickListener(v -> {
            startActivity(new Intent(this, com.example.itmda3.RecommendationsActivity.class));
        });
    }
}
