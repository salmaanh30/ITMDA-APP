package com.example.heartfitapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "HeartFit.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_REPORTS = "Reports";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TEXT = "report_text";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_REPORTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TEXT + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPORTS);
        onCreate(db);
    }

    // Add new report
    public boolean insertReport(String text) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TEXT, text);
        long result = db.insert(TABLE_REPORTS, null, values);
        db.close();
        return result != -1;
    }

    // Get all reports
    public ArrayList<String> getAllReports() {
        ArrayList<String> reports = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_REPORTS, null);

        if (cursor.moveToFirst()) {
            do {
                reports.add(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return reports;
    }

    // Update report
    public boolean updateReport(String oldText, String newText) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TEXT, newText);
        int rows = db.update(TABLE_REPORTS, values, COLUMN_TEXT + "=?", new String[]{oldText});
        db.close();
        return rows > 0;
    }

    // Delete report
    public boolean deleteReport(String text) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_REPORTS, COLUMN_TEXT + "=?", new String[]{text});
        db.close();
        return rows > 0;
    }
}
