package com.example.itmda3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class ReportsActivity extends AppCompatActivity {

    RecyclerView recyclerReports;
    Button btnAddReport, btnBackToDashboard;
    ReportsAdapter adapter;
    ArrayList<String> reportList;
    com.example.heartfitapp.DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        recyclerReports = findViewById(R.id.recyclerReports);
        btnAddReport = findViewById(R.id.btnAddReport);
        btnBackToDashboard = findViewById(R.id.btnBackToDashboard);

        dbHelper = new com.example.heartfitapp.DatabaseHelper(this);
        reportList = dbHelper.getAllReports();

        recyclerReports.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ReportsAdapter(reportList, this, dbHelper);
        recyclerReports.setAdapter(adapter);

        btnAddReport.setOnClickListener(v -> showAddDialog());

        btnBackToDashboard.setOnClickListener(v -> {
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        });
    }

    private void showAddDialog() {
        EditText input = new EditText(this);
        input.setHint("Enter heart risk summary");

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Add New Report")
                .setView(input)
                .setPositiveButton("Add", (DialogInterface dialog, int which) -> {
                    String report = input.getText().toString();
                    if (!report.isEmpty()) {
                        if (dbHelper.insertReport(report)) {
                            reportList.add(report);
                            adapter.notifyItemInserted(reportList.size() - 1);
                        } else {
                            Toast.makeText(this, "Error saving report", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Report cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
