package com.example.itmda3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class HeartRiskActivity extends AppCompatActivity {

    EditText edtAge, edtBloodPressure, edtCholesterol, edtSmoking;
    Button btnCalculateRisk;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_risk);

        edtAge = findViewById(R.id.edtAge);
        edtBloodPressure = findViewById(R.id.edtBloodPressure);
        edtCholesterol = findViewById(R.id.edtCholesterol);
        edtSmoking = findViewById(R.id.edtSmoking);
        btnCalculateRisk = findViewById(R.id.btnCalculateRisk);
        txtResult = findViewById(R.id.txtResult);

        btnCalculateRisk.setOnClickListener(v -> calculateRisk());
    }

    private void calculateRisk() {
        try {
            int age = Integer.parseInt(edtAge.getText().toString());
            double bp = Double.parseDouble(edtBloodPressure.getText().toString());
            double cholesterol = Double.parseDouble(edtCholesterol.getText().toString());
            String smoking = edtSmoking.getText().toString().trim().toLowerCase();

            double riskScore = 0;

            // Simple risk calculation (placeholder logic)
            if (age > 45) riskScore += 2;
            if (bp > 130) riskScore += 2;
            if (cholesterol > 200) riskScore += 2;
            if (smoking.equals("yes")) riskScore += 3;

            String riskLevel;
            if (riskScore <= 2) riskLevel = "Low";
            else if (riskScore <= 5) riskLevel = "Moderate";
            else riskLevel = "High";

            txtResult.setText("Your estimated heart risk is: " + riskLevel);
        } catch (Exception e) {
            Toast.makeText(this, "Please fill in all fields correctly", Toast.LENGTH_SHORT).show();
        }
    }
}
