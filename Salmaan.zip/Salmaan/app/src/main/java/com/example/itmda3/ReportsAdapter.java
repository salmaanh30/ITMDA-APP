package com.example.itmda3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.EditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReportsAdapter extends RecyclerView.Adapter<ReportsAdapter.ReportViewHolder> {

    private ArrayList<String> reports;
    private Context context;
    private com.example.heartfitapp.DatabaseHelper dbHelper;

    public ReportsAdapter(ArrayList<String> reports, Context context, com.example.heartfitapp.DatabaseHelper dbHelper) {
        this.reports = reports;
        this.context = context;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_report, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        String report = reports.get(position);
        holder.txtReport.setText(report);

        // Click to open report details
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ReportDetailsActivity.class);
            intent.putExtra("report_text", report);
            context.startActivity(intent);
        });

        // Edit report inline
        holder.btnEdit.setOnClickListener(v -> {
            EditText input = new EditText(context);
            input.setText(report);

            new AlertDialog.Builder(context)
                    .setTitle("Edit Report")
                    .setView(input)
                    .setPositiveButton("Save", (dialog, which) -> {
                        String newText = input.getText().toString();
                        if (!newText.isEmpty()) {
                            if (dbHelper.updateReport(report, newText)) {
                                reports.set(position, newText);
                                notifyItemChanged(position);
                            }
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Delete report
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Report")
                    .setMessage("Are you sure you want to delete this report?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (dbHelper.deleteReport(report)) {
                            reports.remove(position);
                            notifyItemRemoved(position);
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return reports.size();
    }

    static class ReportViewHolder extends RecyclerView.ViewHolder {
        TextView txtReport;
        ImageButton btnEdit, btnDelete;

        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            txtReport = itemView.findViewById(R.id.txtReport);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
