package com.example.itmda3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ReportDetailsActivity extends AppCompatActivity {

    EditText edtReportDetails;
    Button btnSaveChanges, btnDeleteReport, btnBack;
    com.example.heartfitapp.DatabaseHelper dbHelper;
    String oldReportText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_details);

        edtReportDetails = findViewById(R.id.edtReportDetails);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnDeleteReport = findViewById(R.id.btnDeleteReport);
        btnBack = findViewById(R.id.btnBack);
        dbHelper = new com.example.heartfitapp.DatabaseHelper(this);

        // Get report data from intent
        oldReportText = getIntent().getStringExtra("report_text");
        edtReportDetails.setText(oldReportText);

        // Save updated report
        btnSaveChanges.setOnClickListener(v -> {
            String newText = edtReportDetails.getText().toString();
            if (!newText.isEmpty()) {
                if (dbHelper.updateReport(oldReportText, newText)) {
                    Toast.makeText(this, "Report updated successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Report cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete report
        btnDeleteReport.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Report")
                    .setMessage("Are you sure you want to delete this report?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (dbHelper.deleteReport(oldReportText)) {
                            Toast.makeText(this, "Report deleted", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(this, "Error deleting report", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        // Back button
        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(this, com.example.itmda3.ReportsActivity.class));
            finish();
        });
    }
}
