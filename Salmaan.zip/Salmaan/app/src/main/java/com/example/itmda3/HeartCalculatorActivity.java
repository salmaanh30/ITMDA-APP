package com.example.itmda3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class HeartCalculatorActivity extends AppCompatActivity {

    EditText edtAge, edtBP, edtCholesterol, edtSmoking;
    Button btnCalcRisk, btnBack;
    TextView txtResult;
    com.example.heartfitapp.DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_calculator);

        edtAge = findViewById(R.id.edtCalcAge);
        edtBP = findViewById(R.id.edtCalcBP);
        edtCholesterol = findViewById(R.id.edtCalcCholesterol);
        edtSmoking = findViewById(R.id.edtCalcSmoking);
        btnCalcRisk = findViewById(R.id.btnCalcRisk);
        btnBack = findViewById(R.id.btnBackCalculator);
        txtResult = findViewById(R.id.txtCalcResult);

        dbHelper = new com.example.heartfitapp.DatabaseHelper(this);

        btnCalcRisk.setOnClickListener(v -> calculateAndSaveRisk());
        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        });
    }

    private void calculateAndSaveRisk() {
        try {
            int age = Integer.parseInt(edtAge.getText().toString());
            double bp = Double.parseDouble(edtBP.getText().toString());
            double cholesterol = Double.parseDouble(edtCholesterol.getText().toString());
            String smoking = edtSmoking.getText().toString().trim().toLowerCase();

            double riskScore = 0;
            if (age > 45) riskScore += 2;
            if (bp > 130) riskScore += 2;
            if (cholesterol > 200) riskScore += 2;
            if (smoking.equals("yes")) riskScore += 3;

            String riskLevel;
            if (riskScore <= 2) riskLevel = "Low";
            else if (riskScore <= 5) riskLevel = "Moderate";
            else riskLevel = "High";

            String reportText = "Age: " + age + " | BP: " + bp + " | Cholesterol: " + cholesterol +
                    " | Smoking: " + smoking + " | Risk: " + riskLevel;

            txtResult.setText("Your estimated heart risk is: " + riskLevel);

            // Save to SQLite
            if (dbHelper.insertReport(reportText)) {
                Toast.makeText(this, "Report saved successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error saving report", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            Toast.makeText(this, "Please fill in all fields correctly", Toast.LENGTH_SHORT).show();
        }
    }
}
